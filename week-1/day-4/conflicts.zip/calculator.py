#!/usr/bin/python3
# Program make a simple calculator that can add, subtract, multiply and divide using functions

print("Select operation.")
print("1.Add")
print("2.Subtract")
print("3.Multiply")
print("4.Divide")

# Take input from the user 
choice = input("Enter choice(1/2/3/4):")

print("Invalid input ",choice)
