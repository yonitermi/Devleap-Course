def main(s):
    return s[::-1]
