def main(a, b, c):
    try:
        return (a + b) / c
    except:
        return "err"



