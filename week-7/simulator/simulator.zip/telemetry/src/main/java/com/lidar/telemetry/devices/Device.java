package com.lidar.telemetry.devices;

public interface Device {
    Reading read();
}
