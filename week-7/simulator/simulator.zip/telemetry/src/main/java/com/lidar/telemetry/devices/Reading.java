package com.lidar.telemetry.devices;

public interface Reading {
    String getType();
    String getName();
    String getData();
}
