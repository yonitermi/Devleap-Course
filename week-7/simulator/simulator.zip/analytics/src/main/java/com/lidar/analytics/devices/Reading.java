package com.lidar.analytics.devices;

public interface Reading {
    String getType();
    String getName();
    String getData();
}
