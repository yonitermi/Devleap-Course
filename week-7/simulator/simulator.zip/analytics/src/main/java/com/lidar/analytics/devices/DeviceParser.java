package com.lidar.analytics.devices;

public interface DeviceParser {
    Reading parse(String reading);
}
