package com.omrispector.spelling.interfaces;

public interface InputReader {
  String read();

  String read(String promptParam);
}
